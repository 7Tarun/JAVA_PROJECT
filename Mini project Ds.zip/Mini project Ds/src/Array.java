import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Array extends JFrame {

	private JPanel contentpane;
	private JTextField length;
	private JTextField insertelement;
	private JTextField position;
	private JTextField deletepos;
	private JTextField displayelem;
	private int arr[];
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Array frame = new Array();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Array() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 636, 353);
		contentpane = new JPanel();
		contentpane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentpane);
		contentpane.setLayout(null);
		
		JLabel heading = new JLabel("ARRAY DATASTRUCTURE");
		heading.setFont(new Font("Algerian", Font.BOLD, 20));
		heading.setBounds(199, 11, 247, 27);
		contentpane.add(heading);
		
		JLabel arraylength = new JLabel("ENTER ARRAY LENGTH");
		arraylength.setFont(new Font("Constantia", Font.BOLD, 14));
		arraylength.setBounds(20, 49, 159, 23);
		contentpane.add(arraylength);
		
		length = new JTextField();
		length.setBounds(209, 46, 103, 26);
		contentpane.add(length);
		length.setColumns(10);
		
		JButton createarray = new JButton("CREATE ARRAY");
		createarray.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//code to insert array length
			int len= Integer.valueOf(length.getText());	
			 arr=new int[len];
			String message="Array of Length"+ len +"created";
			JOptionPane.showMessageDialog(contentpane, message);
				
			}
		});
		createarray.setFont(new Font("Constantia", Font.BOLD, 14));
		createarray.setBounds(334, 45, 137, 27);
		contentpane.add(createarray);
		
		JLabel lblEnterArrayElements = new JLabel("ENTER INTEGER ELEMENT");
		lblEnterArrayElements.setFont(new Font("Constantia", Font.BOLD, 14));
		lblEnterArrayElements.setBounds(20, 100, 183, 18);
		contentpane.add(lblEnterArrayElements);
		
		insertelement = new JTextField();
		insertelement.setColumns(10);
		insertelement.setBounds(209, 97, 103, 26);
		contentpane.add(insertelement);
		
		JLabel lblPosition = new JLabel("POSITION");
		lblPosition.setFont(new Font("Constantia", Font.BOLD, 14));
		lblPosition.setBounds(325, 100, 69, 18);
		contentpane.add(lblPosition);
		
		position = new JTextField();
		position.setColumns(10);
		position.setBounds(404, 97, 103, 26);
		contentpane.add(position);
		
		JButton Insert = new JButton("INSERT");
		Insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//insert element in position
				int elem=Integer.valueOf(insertelement.getText());
				int pos=Integer.valueOf(position.getText());
				arr[pos]=elem;
				String message="element"+elem+"inserted @"+pos;
				JOptionPane.showMessageDialog(contentpane, message);
				insertelement.setText("");
				position.setText("");
				
				
			}
		});
		Insert.setFont(new Font("Constantia", Font.BOLD, 14));
		Insert.setBounds(517, 96, 95, 27);
		contentpane.add(Insert);
		
		JLabel lblDeleteElement = new JLabel("DELETE ELEMENT");
		lblDeleteElement.setFont(new Font("Constantia", Font.BOLD, 14));
		lblDeleteElement.setBounds(20, 147, 124, 18);
		contentpane.add(lblDeleteElement);
		
		deletepos = new JTextField();
		deletepos.setColumns(10);
		deletepos.setBounds(209, 144, 103, 26);
		contentpane.add(deletepos);
		
		JButton delete = new JButton("DELETE");
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//delete element in given position
				int pos = Integer.valueOf(deletepos.getText());
				String message="element delete at"+ pos;
				JOptionPane.showMessageDialog(contentpane,message );
				arr[pos]=0;
				deletepos.setText("");
				
			}
		});
		delete.setFont(new Font("Constantia", Font.BOLD, 14));
		delete.setBounds(341, 143, 105, 27);
		contentpane.add(delete);
		
		JButton display = new JButton("DISPLAY");
		display.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//display array elements
				String msg="";
				for(int i=0;i<=arr.length-1;i++) {
					msg=msg+" "+arr[i];
				}
				displayelem.setText(msg);
			}
		});
		display.setFont(new Font("Constantia", Font.BOLD, 14));
		display.setBounds(229, 205, 113, 27);
		contentpane.add(display);
		
		displayelem = new JTextField();
		displayelem.setBackground(new Color(223, 254, 255));
		displayelem.setColumns(10);
		displayelem.setBounds(90, 243, 417, 35);
		contentpane.add(displayelem);
		
		JButton Home = new JButton("HOME");
		Home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Home().setVisible(true);
				new Array().setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			}
		});
		Home.setBounds(242, 289, 89, 23);
		contentpane.add(Home);
	}
}
