import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Queue extends JFrame {

	private JPanel contentPane;
	private JTextField Size;
	private JTextField Element;
	private JTextField Display;
    private int q[];
    private int size;
    private int r=-1;
    private int f=0;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Queue frame = new Queue();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Queue() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 731, 562);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
	
		JLabel lblNewLabel = new JLabel("QUEUE DATASTRUCTURE");
		lblNewLabel.setBounds(255, 11, 241, 27);
		lblNewLabel.setFont(new Font("Algerian", Font.BOLD, 20));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ENTER THE SIZE OF QUEUE");
		lblNewLabel_1.setFont(new Font("Constantia", Font.BOLD, 14));
		lblNewLabel_1.setBounds(39, 65, 187, 18);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("ENTER THE ELEMENT");
		lblNewLabel_1_1.setFont(new Font("Constantia", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(39, 215, 149, 18);
		contentPane.add(lblNewLabel_1_1);
	
		
		JButton CreateQueue = new JButton("CREATE QUEUE");
		CreateQueue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				size= Integer.valueOf(Size.getText());	
				 q=new int[size];
				String message="Stack of Size "+ size +" created";
				JOptionPane.showMessageDialog(contentPane, message);
				
			}
		});
		CreateQueue.setBounds(397, 61, 149, 23);
		contentPane.add(CreateQueue);
		
		JButton Insert = new JButton("INSERT");
		Insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int elem;
				if(r==size-1) {
					JOptionPane.showMessageDialog(contentPane, "INSERT not possible");
				}else {
				 elem=Integer.valueOf(Element.getText());
				++r;
				q[r]=elem;
				Element.setText("");
				JOptionPane.showMessageDialog(contentPane, "INSERT successfull");
				} //Display.setText("");
				}
		});
		Insert.setBounds(385, 211, 111, 23);
		contentPane.add(Insert);
		
		JButton Delete = new JButton("DELETE");
		Delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(r==-1) {
					JOptionPane.showMessageDialog(contentPane, "DELETE not possible");
				}else {
				 
				++f;
	
				
				JOptionPane.showMessageDialog(contentPane, "DELETE successfull");
				}// Display.setText("");
				}
			
		});
		Delete.setBounds(235, 260, 111, 23);
		contentPane.add(Delete);
		
		JButton btnDisplay = new JButton("DISPLAY");
		btnDisplay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(r==-1) {
					JOptionPane.showMessageDialog(contentPane, "Display not possible");
				}else {
				 
					String msg="";
					for(int i=f;i<=r;i++) {
						msg=msg+" "+q[i];
					}
					Display.setText(msg);
					
	
				
				//JOptionPane.showMessageDialog(contentPane, "pop successfull");
				}
				} 
			
			
		});
		btnDisplay.setBounds(235, 306, 111, 23);
		contentPane.add(btnDisplay);
		JButton Home = new JButton("HOME");
		Home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Home().setVisible(true);
				new Array().setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			}
		});
		Home.setBounds(279, 443, 89, 23);
		contentPane.add(Home);
		
		Size = new JTextField();
		Size.setBounds(255, 62, 96, 20);
		contentPane.add(Size);
		Size.setColumns(10);
		
		Element = new JTextField();
		Element.setColumns(10);
		Element.setBounds(230, 212, 96, 20);
		contentPane.add(Element);
		
		Display = new JTextField();
		Display.setBackground(new Color(128, 255, 255));
		Display.setColumns(10);
		Display.setBounds(121, 350, 470, 45);
		contentPane.add(Display);
		
	}
}
