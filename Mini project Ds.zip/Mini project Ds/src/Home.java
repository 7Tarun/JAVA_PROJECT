import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Home extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 578, 422);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBackground(new Color(85, 85, 85));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel HEADING = new JLabel("Data Structures Home");
		HEADING.setFont(new Font("Times New Roman", Font.BOLD, 20));
		HEADING.setForeground(new Color(0, 0, 64));
		HEADING.setBackground(new Color(0, 0, 113));
		HEADING.setBounds(173, 23, 188, 24);
		contentPane.add(HEADING);
		
		JButton array = new JButton("ARRAYS");
		array.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Array a =new Array();
				//a.setVisible(true);
				new Array().setVisible(true);
			}
			
		});
		array.setFont(new Font("Constantia", Font.BOLD, 14));
		array.setBounds(193, 63, 139, 27);
		contentPane.add(array);
		
		JButton stack = new JButton("STACKS");
		stack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Stack().setVisible(true);
			}
		});
		stack.setFont(new Font("Constantia", Font.BOLD, 14));
		stack.setBounds(30, 124, 112, 27);
		contentPane.add(stack);
		
		JButton queue = new JButton("QUEUS");
		queue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Queue().setVisible(true);
			}
		});
		queue.setFont(new Font("Constantia", Font.BOLD, 14));
		queue.setBounds(192, 124, 107, 27);
		contentPane.add(queue);
		
		JButton cqueue = new JButton("CIRCULAR QUEUE");
		cqueue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CircularQueue().setVisible(true);
			}
		});
		cqueue.setFont(new Font("Constantia", Font.BOLD, 14));
		cqueue.setBounds(332, 124, 181, 27);
		contentPane.add(cqueue);
		
		JButton sll = new JButton("SINGLE LINKED LIST");
		sll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new SingleLinkedList().setVisible(true);
			}
		});
		sll.setFont(new Font("Constantia", Font.BOLD, 14));
		sll.setBounds(33, 186, 193, 27);
		contentPane.add(sll);
		
		JButton dll = new JButton("DOUBLE LINKED LIST");
		dll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DoubleLinkedList().setVisible(true);
			}
		});
		dll.setFont(new Font("Constantia", Font.BOLD, 14));
		dll.setBounds(314, 186, 199, 27);
		contentPane.add(dll);
	}
}
