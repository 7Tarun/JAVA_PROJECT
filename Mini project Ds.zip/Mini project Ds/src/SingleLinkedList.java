import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

//import SingleLinkedList.Node;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class SingleLinkedList extends JFrame {
	public class Node{
		private int data;
		private Node link;
	}
	private Node first;
	

	private JPanel contentPane;
	private JTextField ELEMENT1;
	private JTextField ELEMENT2;
	private JTextField DISPLAY;
	public void close()
	{
		WindowEvent closeWindow=new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SingleLinkedList frame = new SingleLinkedList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SingleLinkedList() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 795, 468);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel l1 = new JLabel("SINGLY LINKED LIST DATASTRUCTURE");
		l1.setFont(new Font("Arial", Font.BOLD, 18));
		l1.setBounds(204, 24, 408, 29);
		contentPane.add(l1);
		
		JLabel l2 = new JLabel("ENTER THE ELEMENT :");
		l2.setFont(new Font("Arial", Font.BOLD, 14));
		l2.setBounds(81, 99, 186, 29);
		contentPane.add(l2);
		
		JLabel l3 = new JLabel("ENTER THE ELEMENT :");
		l3.setFont(new Font("Arial", Font.BOLD, 14));
		l3.setBounds(81, 170, 157, 17);
		contentPane.add(l3);
		
		ELEMENT1 = new JTextField();
		ELEMENT1.setBounds(286, 104, 223, 20);
		contentPane.add(ELEMENT1);
		ELEMENT1.setColumns(10);
		
		ELEMENT2 = new JTextField();
		ELEMENT2.setBounds(286, 169, 223, 20);
		contentPane.add(ELEMENT2);
		ELEMENT2.setColumns(10);
		
		JButton INSERTREAR = new JButton("INSERT REAR");
		INSERTREAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Node temp;
				int elem=Integer.valueOf(ELEMENT1.getText());
				Node newnode=new Node();
				newnode.data=elem;
				newnode.link=null;
				if(first==null)
				{
				first=newnode;
				JOptionPane.showMessageDialog(contentPane, "Element Insert is"+first.data);
				ELEMENT1.setText("");
				}
				else {
						temp=first;
						while(temp.link!=null)
						{
							temp=temp.link;
							
						}
						temp.link=newnode;
						JOptionPane.showMessageDialog(contentPane, "Element inserted is"+elem);
						ELEMENT1.setText("");
					}
				
			}
				
			
		});
		INSERTREAR.setFont(new Font("Arial", Font.BOLD, 14));
		INSERTREAR.setBounds(561, 103, 150, 23);
		contentPane.add(INSERTREAR);
		
		JButton INSERTFRONT = new JButton("INSERT FRONT");
		INSERTFRONT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int elem=Integer.valueOf(ELEMENT2.getText());
				Node newnode=new Node();
				newnode.data=elem;
				newnode.link=null;
				if(first==null)
				{
					first=newnode;
					JOptionPane.showMessageDialog(contentPane, "Element inserted is"+first.data);
					ELEMENT2.setText("");
				}
				else
				{
					newnode.link=first;
					first=newnode;
					JOptionPane.showMessageDialog(contentPane, "Element inserted is"+elem);
					ELEMENT2.setText("");
				}
			}
		});
		INSERTFRONT.setFont(new Font("Arial", Font.BOLD, 14));
		INSERTFRONT.setBounds(561, 168, 150, 23);
		contentPane.add(INSERTFRONT);
		
		JButton DELETEFRONT = new JButton("DELETE FRONT");
		DELETEFRONT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(first==null)
				{
				  JOptionPane.showMessageDialog(contentPane, "Deletion Not Possible");
			    }
			    else if(first.link==null)
			    {
				JOptionPane.showMessageDialog(contentPane, "Element Deleted is"+first.data);
				first=null;
			    }
				else
				{
					JOptionPane.showMessageDialog(contentPane, "Element Deleted is"+first.data);
					 first=first.link;
				}
				
				
			}
		});
		DELETEFRONT.setFont(new Font("Arial", Font.BOLD, 14));
		DELETEFRONT.setBounds(561, 278, 150, 23);
		contentPane.add(DELETEFRONT);
		
		JButton DELETEREAR = new JButton("DELETE REAR");
		DELETEREAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Node temp;
				if(first==null)
				{
					JOptionPane.showMessageDialog(contentPane, "Deletion Not Possible");
				}
				else if(first.link==null)
				{
					JOptionPane.showMessageDialog(contentPane, "Element deleted is"+first.data);
					 first=null;
				}
				else
				{
					temp=first;
					while(temp.link.link!=null)
					{
					 temp=temp.link;
					}
					JOptionPane.showMessageDialog(contentPane,"Element deleted id"+temp.link.data);
					temp.link=null;
				}
				
			}
		});
		DELETEREAR.setFont(new Font("Arial", Font.BOLD, 14));
		DELETEREAR.setBounds(561, 223, 150, 23);
		contentPane.add(DELETEREAR);
		
		JButton DISPLAYBTN = new JButton("DISPLAY");
		DISPLAYBTN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String msg="";
				Node temp;
				 if(first==null)
				{
					 JOptionPane.showMessageDialog(contentPane, "Display Not Possible");
				}
				 else if(first.link==null)
				{
					 msg=String.valueOf(first.data);
					 DISPLAY.setText(msg);
				}
				else
				{
				temp=first;
				while(temp!=null)
				{
					msg=msg+" "+temp.data;
					DISPLAY.setText(msg);
					temp=temp.link;
					
				}
				}
				
			}
		});
		DISPLAYBTN.setFont(new Font("Arial", Font.BOLD, 14));
		DISPLAYBTN.setBounds(81, 344, 145, 42);
		contentPane.add(DISPLAYBTN);
		
		DISPLAY = new JTextField();
		DISPLAY.setBounds(291, 344, 344, 42);
		contentPane.add(DISPLAY);
		DISPLAY.setColumns(10);
		
		JButton btnNewButton = new JButton(" HOME");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				close();
				
				new Home().setVisible(true);
			}
		});
		btnNewButton.setBounds(668, 355, 89, 23);
		contentPane.add(btnNewButton);
	}
}
