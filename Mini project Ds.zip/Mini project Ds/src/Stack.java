import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Stack extends JFrame {

	private JPanel contentPane;
	private JTextField Size;
	private JTextField Element;
	private JTextField Display;
	private int S[];
	private int size;
	private int top=-1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Stack frame = new Stack();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Stack() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 755, 579);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("STACK DATASTRUCTURE");
		lblNewLabel.setBounds(255, 11, 241, 27);
		lblNewLabel.setFont(new Font("Algerian", Font.BOLD, 20));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ENTER THE SIZE OF STACK");
		lblNewLabel_1.setFont(new Font("Constantia", Font.BOLD, 14));
		lblNewLabel_1.setBounds(39, 65, 182, 18);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("ENTER THE ELEMENT");
		lblNewLabel_1_1.setFont(new Font("Constantia", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(39, 215, 149, 18);
		contentPane.add(lblNewLabel_1_1);
		
		Size = new JTextField();
		Size.setBounds(277, 62, 53, 20);
		contentPane.add(Size);
		Size.setColumns(10);
		
		Element = new JTextField();
		Element.setColumns(10);
		Element.setBounds(242, 212, 88, 20);
		contentPane.add(Element);
		
		Display = new JTextField();
		Display.setBackground(new Color(181, 255, 255));
		Display.setBounds(111, 398, 473, 43);
		contentPane.add(Display);
		Display.setColumns(10);
		
		JButton CreateStack = new JButton("CREATE STACK");
		CreateStack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				size= Integer.valueOf(Size.getText());	
				 S=new int[size];
				String message="Stack of Size "+ size +" created";
				JOptionPane.showMessageDialog(contentPane, message);
				
			}
		});
		CreateStack.setBounds(385, 61, 149, 23);
		contentPane.add(CreateStack);
		
		JButton Push = new JButton("PUSH");
		Push.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int elem;
				if(top==size-1) {
					JOptionPane.showMessageDialog(contentPane, "push not possible");
				}else {
				 elem=Integer.valueOf(Element.getText());
				++top;
				S[top]=elem;
				Element.setText("");
				JOptionPane.showMessageDialog(contentPane, "push successfull");
				} Display.setText("");
				}
		});
		Push.setBounds(385, 211, 111, 23);
		contentPane.add(Push);
		
		JButton Pop = new JButton("POP");
		Pop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(top==-1) {
					JOptionPane.showMessageDialog(contentPane, "pop not possible");
				}else {
				 
				--top;
	
				
				JOptionPane.showMessageDialog(contentPane, "pop successfull");
				} Display.setText("");
				}
			
		});
		Pop.setBounds(235, 260, 111, 23);
		contentPane.add(Pop);
		
		JButton btnDisplay = new JButton("DISPLAY");
		btnDisplay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(top==-1) {
					JOptionPane.showMessageDialog(contentPane, "Display not possible");
				}else {
				 
					String msg="";
					for(int i=top;i>=0;i--) {
						msg=msg+" "+S[i];
					}
					Display.setText(msg);
					
	
				
				//JOptionPane.showMessageDialog(contentPane, "pop successfull");
				}
				} 
			
			
		});
		btnDisplay.setBounds(235, 306, 111, 23);
		contentPane.add(btnDisplay);
		JButton Home = new JButton("HOME");
		Home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Home().setVisible(true);
				new Array().setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			}
		});
		Home.setBounds(289, 497, 89, 23);
		contentPane.add(Home);
	}
}
