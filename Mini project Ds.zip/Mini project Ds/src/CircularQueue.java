import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CircularQueue extends JFrame {

	private JPanel contentPane;
	private JTextField Size;
	private JTextField Element;
	private JTextField Display;
	private int cq[];
	private int size;
	private int r=-1;
	private int f=0;
	private int count=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CircularQueue frame = new CircularQueue();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CircularQueue() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 712, 560);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CIRCULAR QUEUE DATASTRUCTURE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(272, 11, 205, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ENTER THE SIZE");
		lblNewLabel_1.setBounds(93, 47, 85, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("ENTER THE ELEMENT");
		lblNewLabel_2.setBounds(93, 167, 110, 14);
		contentPane.add(lblNewLabel_2);
		
		Size = new JTextField();
		Size.setBounds(239, 44, 96, 20);
		contentPane.add(Size);
		Size.setColumns(10);
		
		Element = new JTextField();
		Element.setBounds(239, 164, 96, 20);
		contentPane.add(Element);
		Element.setColumns(10);
		
		JButton Create = new JButton("CREATE CIRCULAR QUEUE");
		Create.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				size= Integer.valueOf(Size.getText());	
				 cq=new int[size];
				String message="Circular queue of Size "+ size +" created";
				JOptionPane.showMessageDialog(contentPane, message);
			}
		});
		Create.setBounds(382, 43, 205, 23);
		contentPane.add(Create);
		
		JButton Insert = new JButton("INSERT");
		Insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int elem;
				if(count==size) {
					JOptionPane.showMessageDialog(contentPane, " Insert not possible");
				}else {
				 elem=Integer.valueOf(Element.getText());
				r=(r+1)%size;
			  cq[r]=elem;
			  ++count;
				Element.setText("");
				JOptionPane.showMessageDialog(contentPane, "Insert successfull");
				} Display.setText("");
				}
			
		});
		Insert.setBounds(413, 163, 89, 23);
		contentPane.add(Insert);
		
		JButton Delete = new JButton("DELETE");
		Delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(count==0) {
					JOptionPane.showMessageDialog(contentPane, "Delete not possible");
				}else {
					f=(f+1)%size;
				--count;
	
				
				JOptionPane.showMessageDialog(contentPane, "Delete successfull");
				} Display.setText("");
			}
		});
		Delete.setBounds(239, 227, 89, 23);
		contentPane.add(Delete);
		
		JButton btnDisplay = new JButton("DISPLAY");
		btnDisplay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(count==0) {
					JOptionPane.showMessageDialog(contentPane, "Display not possible");
				}else {
				 
					String msg="";
					for(int i=1;i<=count;i++) {
						msg=msg+" "+cq[i];
					}
					Display.setText(msg);
					
	
				
				//JOptionPane.showMessageDialog(contentPane, "pop successfull");
				}
			}
		});
		btnDisplay.setBounds(246, 275, 89, 23);
		contentPane.add(btnDisplay);
		
		Display = new JTextField();
		Display.setBounds(171, 355, 354, 40);
		contentPane.add(Display);
		Display.setColumns(10);
	}
}
