import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

//import DoublyLinkedList.Node;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;

public class DoubleLinkedList extends JFrame {
	public class Node
	{
	 private Node prelink;
	 private int data;
	 private Node nextlink;
	}
	 private Node first;

	private JPanel contentPane;
	private JTextField ELEMENT1;
	private JTextField ELEMENT2;
	private JTextField DISPLAY;
	public void close()
	{
		WindowEvent closeWindow=new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DoubleLinkedList frame = new DoubleLinkedList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DoubleLinkedList() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 719, 431);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(208, 208, 208));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Double Linked List");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 18));
		lblNewLabel.setBounds(265, 27, 165, 22);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ENTER THE ELEMENT :");
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_1.setBounds(28, 88, 157, 17);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("ENTER THE ELEMENT :");
		lblNewLabel_1_1.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(28, 139, 157, 17);
		contentPane.add(lblNewLabel_1_1);
		
		ELEMENT1 = new JTextField();
		ELEMENT1.setBounds(209, 87, 96, 20);
		contentPane.add(ELEMENT1);
		ELEMENT1.setColumns(10);
		
		ELEMENT2 = new JTextField();
		ELEMENT2.setColumns(10);
		ELEMENT2.setBounds(209, 138, 96, 20);
		contentPane.add(ELEMENT2);
		
		JButton INSERTREAR = new JButton("INSERT REAR");
		INSERTREAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Node temp;
				 int elem=Integer.valueOf(ELEMENT1.getText());
				 Node newnode=new Node();
				 newnode.data=elem;
				 newnode.prelink=null;
				 newnode.nextlink=null;
				 if(first==null)
				 {
					 first=newnode;
				 JOptionPane.showMessageDialog(contentPane, "Element Inserted is"+first.data);
				ELEMENT1.setText("");
				}
				 else
				 {
					 temp=first;
				 while(temp.nextlink!=null)
				{
					 temp=temp.nextlink;
				}
				 temp.nextlink=newnode;
				 newnode.prelink=temp;
				 JOptionPane.showMessageDialog(contentPane, "Element Inserted is"+elem);
				 ELEMENT1.setText("");
				}
			}
		});
		INSERTREAR.setFont(new Font("Arial", Font.BOLD, 14));
		INSERTREAR.setBounds(445, 86, 150, 23);
		contentPane.add(INSERTREAR);
		
		JButton INSERTFRONT = new JButton("INSERT FRONT");
		INSERTFRONT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int elem=Integer.valueOf(ELEMENT2.getText());
				 Node newnode=new Node();
				 newnode.data=elem;
				newnode.prelink=null;
				 newnode.nextlink=null;
				 if(first==null)
				 {
					 first=newnode;

				JOptionPane.showMessageDialog(contentPane, "Element Inserted is"+first.data);
				 ELEMENT2.setText("");
				}
				 else
				 {
					 newnode.nextlink=first;
				 first.prelink=newnode;
				 first=newnode;
				 JOptionPane.showMessageDialog(contentPane, "Element Inserted is"+elem);
				 ELEMENT2.setText("");
				}
			}
		});
		INSERTFRONT.setFont(new Font("Arial", Font.BOLD, 14));
		INSERTFRONT.setBounds(445, 133, 150, 23);
		contentPane.add(INSERTFRONT);
		
		JButton DELETEREAR = new JButton("DELETE REAR");
		DELETEREAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Node temp;
				if(first==null)
				 {
					JOptionPane.showMessageDialog(contentPane, "Deletion Not Possible");
				}
				else if(first.nextlink==null)
				 {
					JOptionPane.showMessageDialog(contentPane, "Element Deleted is"+first.data);
				 first=null;
				}
				else
				{
					temp=first;
				 while(temp.nextlink!=null)
				 {
					 temp=temp.nextlink;
				 }
				 JOptionPane.showMessageDialog(contentPane, "Element Deleted is"+temp.nextlink.data);
				 temp.nextlink=null;
				}
			}
		});
		DELETEREAR.setFont(new Font("Arial", Font.BOLD, 14));
		DELETEREAR.setBounds(445, 181, 150, 23);
		contentPane.add(DELETEREAR);
		
		JButton DELETEFRONT = new JButton("DELETE FRONT");
		DELETEFRONT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(first==null)
					{
					JOptionPane.showMessageDialog(contentPane, "Deletion Not Possible");
					}
					 else if(first.nextlink==null)
					{
					 JOptionPane.showMessageDialog(contentPane, "Element Deleted is"+first.data);
					 first=null;
					 }
					 else
					 {

					 JOptionPane.showMessageDialog(contentPane, "Element Deleted is"+first.data);
					 first=first.nextlink;
					 first.prelink=null;
					 }
			}
		});
		DELETEFRONT.setFont(new Font("Arial", Font.BOLD, 14));
		DELETEFRONT.setBounds(445, 231, 150, 23);
		contentPane.add(DELETEFRONT);
		
		DISPLAY = new JTextField();
		DISPLAY.setBounds(10, 317, 322, 28);
		contentPane.add(DISPLAY);
		DISPLAY.setColumns(10);
		
		JButton DISPLAYFORWARD = new JButton("DISPLAY FORWARD");
		DISPLAYFORWARD.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String msg="";
				 Node temp;
				 if(first==null)
				{
				 JOptionPane.showMessageDialog(contentPane, "Display Not Possible");
				}
				 else if(first.nextlink==null)
				{
				 msg=String.valueOf(first.data);
				 DISPLAY.setText(msg);
				 }
				 else
				 {
					 temp=first;
				 while(temp!=null)
				{
				 msg=msg+" "+temp.data;
				 DISPLAY.setText(msg);
				 temp=temp.nextlink;
				}
				 }
			}
		});
		DISPLAYFORWARD.setFont(new Font("Arial", Font.BOLD, 14));
		DISPLAYFORWARD.setBounds(342, 316, 171, 28);
		contentPane.add(DISPLAYFORWARD);
		
		JButton btnNewButton_4_1 = new JButton("DISPLAY REVERSE");
		btnNewButton_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String msg="";
				 Node temp;
				 if(first==null)
				 {
					 JOptionPane.showMessageDialog(contentPane, "Display Not Possible");
				}
				 else if(first.nextlink==null)
				 {
		 		 msg=String.valueOf(first.data);
				 DISPLAY.setText(msg);
				}
 				else
 				{
				 temp=first;
				 while(temp.nextlink!=null)
				 {
					 temp=temp.nextlink;
				}
				 while(temp!=null)
				 {

				msg=msg+" "+temp.data;
				 DISPLAY.setText(msg);
				 temp=temp.prelink;
				}
 	}
			}
		});
		btnNewButton_4_1.setFont(new Font("Arial", Font.BOLD, 14));
		btnNewButton_4_1.setBounds(524, 316, 171, 28);
		contentPane.add(btnNewButton_4_1);
		
		JButton btnNewButton = new JButton("HOME");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				close();
				
				new Home().setVisible(true);
			}
		});
		btnNewButton.setBounds(534, 360, 89, 23);
		contentPane.add(btnNewButton);
	}
}
