package com.bankxapp.bankxapp.controller;


import com.bankxapp.bankxapp.Customer;
import com.bankxapp.bankxapp.Transcation;
import com.bankxapp.bankxapp.services.TransactionService;
import jakarta.transaction.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.transaction.xa.XAResource;

@RestController
@RequestMapping("/transaction")
public class TransactionController

{

    private TransactionService transactionService;
    @GetMapping({"id"})

    public Transaction transcendentalists(Long id, String accountNumber, String Despriction, double amount){

        return new Transaction() {
            @Override
            public void commit() throws RollbackException, HeuristicMixedException, HeuristicRollbackException, SecurityException, IllegalStateException, SystemException {

            }

            @Override
            public boolean delistResource(XAResource xaResource, int i) throws IllegalStateException, SystemException {
                return false;
            }

            @Override
            public boolean enlistResource(XAResource xaResource) throws RollbackException, IllegalStateException, SystemException {
                return false;
            }

            @Override
            public int getStatus() throws SystemException {
                return 0;
            }

            @Override
            public void registerSynchronization(Synchronization synchronization) throws RollbackException, IllegalStateException, SystemException {

            }

            @Override
            public void rollback() throws IllegalStateException, SystemException {

            }

            @Override
            public void setRollbackOnly() throws IllegalStateException, SystemException {

            }
        };
    }

    @PostMapping({"id"})
    public String createTranscationDetials(){

        return "SUCCESSFULL CREATED";
    }


}


