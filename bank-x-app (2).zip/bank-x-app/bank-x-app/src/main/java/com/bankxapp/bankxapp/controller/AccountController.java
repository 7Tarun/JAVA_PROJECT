package com.bankxapp.bankxapp.controller;

import com.bankxapp.bankxapp.Account;
import com.bankxapp.bankxapp.Customer;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/account")
public class AccountController {

    @GetMapping({"/id"})

    public Account getAccountdetials(Long id, double balance){

        return new Account(101L,500f);
    }

    @PostMapping({"/id"})
    public String createAccountDetials(){

        return "SUCCESSFULL CREATED";
    }
}
