package com.bankxapp.bankxapp;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionRepository extends JpaRepository<Transcation, Long> {
}
