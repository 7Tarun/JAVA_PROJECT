package com.bankxapp.bankxapp.services;

import com.bankxapp.bankxapp.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
   @Autowired
    private CustomerRepository customerRepository;

   @Autowired
    private AccountService accountService;

    @Autowired
    private TransactionService transactionService;
   private Customer customer;

   private Account account;

   private Transcation transcation;

 public Customer OnBoardCustomer(String name){
     customer.setName(name);

    return customerRepository.save(customer);
 }

    public int setBalance(){

        return 500;
    }


}

