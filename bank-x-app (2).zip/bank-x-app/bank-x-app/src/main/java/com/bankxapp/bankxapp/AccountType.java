package com.bankxapp.bankxapp;

public enum AccountType {
        savingsAccount,
        currentAccount

}
