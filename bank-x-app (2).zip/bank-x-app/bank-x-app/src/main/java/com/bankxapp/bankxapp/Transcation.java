package com.bankxapp.bankxapp;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Transcation {
    @Id

    private Long id;

    private String accountNumber;
    private String Despriction;
    private double amount;

    public Transcation() {
    }

    public Transcation(Long id, String despriction, double amount, String accountNumber) {
        this.id = id;
        this.accountNumber=accountNumber;
        Despriction = despriction;
        this.amount = amount;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDespriction() {
        return Despriction;
    }

    public void setDespriction(String despriction) {
        Despriction = despriction;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
}
