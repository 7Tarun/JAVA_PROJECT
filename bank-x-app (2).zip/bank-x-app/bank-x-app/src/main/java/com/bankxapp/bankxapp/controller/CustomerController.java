package com.bankxapp.bankxapp.controller;


import com.bankxapp.bankxapp.Customer;
import com.bankxapp.bankxapp.services.CustomerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    public CustomerService customerService;


@GetMapping({"/id"})

public Customer getCustomerdetials(Long id, String name){

    return new Customer(101L,"tarun");
}

@PostMapping({"/id"})
    public String createCustomerDetials(){

   return "SUCCESSFULL CREATED";
}





}
